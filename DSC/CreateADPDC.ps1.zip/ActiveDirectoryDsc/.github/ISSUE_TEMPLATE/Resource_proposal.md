---
name: New resource proposal
about: If you have a new resource proposal that you think should be added to this resource module.
---
<!--
    Thank you for contributing and making this resource module better!

    ISSUE TITLE:
    Please prefix the issue title with a proposed resource name,
    e.g. 'NewResourceName: New resource proposal'

    ISSUE DESCRIPTION (this template):
    Please propose the new resource under each header below.

    PLEASE KEEP THE HEADERS, but you may remove this comment block.
-->
### Description

### Proposed properties

### Special considerations or limitations
